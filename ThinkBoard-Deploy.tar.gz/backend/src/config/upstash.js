import {Ratelimit} from "@upstash/ratelimit";
import {Redis} from "@upstash/redis"

import dotenv from "dotenv";

dotenv.config();

// create ratelimiter that allows 100 requests per 60 seconds
const ratelimit = new Ratelimit({
    redis: Redis.fromEnv(),
    limiter: Ratelimit.slidingWindow(300, "60 s"),
});

export default ratelimit;